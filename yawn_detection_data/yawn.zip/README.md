# opencv-yawnDetector
This is a small script based on Python OpenCV to detect yawns. 

Tested on Python 2.x and openCV 2.x
